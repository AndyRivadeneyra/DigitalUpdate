package addd;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {

	public static Connection getConnection() {
		Connection con;
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost/digitalupdate?useUnicode=true&useJDBCCompliantTimeZoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC","root","12345");
					return con;
		}catch(Exception e) {
			e.printStackTrace();
			return null;
		}
	}
}
