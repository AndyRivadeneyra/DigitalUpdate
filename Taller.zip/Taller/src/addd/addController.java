package addd;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.sql.*;

import static java.lang.Float.parseFloat;

public class addController {

    @FXML private TextField modCorreo;
    @FXML private TextField modTelefono;
    @FXML private TextField modNombre;
    @FXML private TextField modMonto;
    @FXML private TextField modApellido;
    Connection conn;

    public void regresarMenu(MouseEvent event){
        try{
            Parent window3;
            window3 = (AnchorPane) FXMLLoader.load(getClass().getResource("../Menu/ViewMenui.fxml"));

            Scene newScene;
            newScene = new Scene(window3);
            newScene.setFill(Color.TRANSPARENT);
            Stage mainWindow;

            mainWindow = (Stage) ((Node)event.getSource()).getScene().getWindow();
            mainWindow.setScene(newScene);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    public void agregar(){
        try{
            String nombre = modNombre.getText();
            String apellido = modApellido.getText();
            float monto = parseFloat(modMonto.getText());
            String emai = modCorreo.getText();
            String tele = modTelefono.getText();
            String sSQL = "INSERT INTO donors (first_name,last_name,donate_recent,last_donated,email,phone) VALUES(?,?,?,?,?,?)";
            String url = "jdbc:mysql://localhost/digitalupdate?useUnicode=true&useJDBCCompliantTimeZoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC";
            conn = DriverManager.getConnection(url,"root","12345");
            Statement st = conn.createStatement();
            PreparedStatement ps = conn.prepareStatement(sSQL);
            ps.setString(1,nombre);
            ps.setString(2,apellido);
            ps.setFloat(3,monto);
            ps.setFloat(4,monto);
            ps.setString(5,emai);
            ps.setString(6,tele);
            ps.executeUpdate();
            modNombre.clear();
            modTelefono.clear();
            modCorreo.clear();
            modMonto.clear();
            modApellido.clear();

        }catch (Exception e){
            e.printStackTrace();
        }
    }

}
