package Menu;



import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


public class MenuController {

    public void accionSalir(MouseEvent event){
        System.exit(0);
    }

    public void regresarLogin(MouseEvent event){
        try{
            Parent window3;
            window3 = (AnchorPane) FXMLLoader.load(getClass().getResource("../Login/ViewLogin.fxml"));

            Scene newScene;
            newScene = new Scene(window3);
            newScene.setFill(Color.TRANSPARENT);
            Stage mainWindow;

            mainWindow = (Stage) ((Node)event.getSource()).getScene().getWindow();
            mainWindow.setScene(newScene);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void abrirSocios(MouseEvent event){
        try{
            Parent window3;
            window3 = (AnchorPane) FXMLLoader.load(getClass().getResource("../ActiveSocies/ViewSocios.fxml"));

            Scene newScene;
            newScene = new Scene(window3);
            newScene.setFill(Color.TRANSPARENT);
            Stage mainWindow;

            mainWindow = (Stage) ((Node)event.getSource()).getScene().getWindow();
            mainWindow.setScene(newScene);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void ventanaAdd(MouseEvent event){
        try{
            Parent window3;
            window3 = (AnchorPane) FXMLLoader.load(getClass().getResource("../addd/ViewAdd.fxml"));

            Scene newScene;
            newScene = new Scene(window3);
            newScene.setFill(Color.TRANSPARENT);
            Stage mainWindow;

            mainWindow = (Stage) ((Node)event.getSource()).getScene().getWindow();
            mainWindow.setScene(newScene);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    public void ventanaCalendar(MouseEvent event){
        try{
            Parent window3;
            window3 = (AnchorPane) FXMLLoader.load(getClass().getResource("../Calendar/ViewCalendar.fxml"));

            Scene newScene;
            newScene = new Scene(window3);
            newScene.setFill(Color.TRANSPARENT);
            Stage mainWindow;

            mainWindow = (Stage) ((Node)event.getSource()).getScene().getWindow();
            mainWindow.setScene(newScene);
        }catch (Exception e){
            e.printStackTrace();
        }
    }



}

