package ActiveSocies;

import javafx.beans.property.Property;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.collections.ObservableList;
import javafx.collections.FXCollections;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;

import java.sql.*;

import static java.lang.Float.parseFloat;


public class SociosController {

    @FXML private TableColumn<Person,String> columnaPhone;
    @FXML private TableColumn<Person,String> columnaFirstName;
    @FXML private TableColumn<Person,String> columnaLastName;
    @FXML private TableColumn<Person,String> columnaEmail;
    @FXML private TableColumn<Person,String> columnaLastDonated;
    @FXML private TableColumn<Person,String> columnaDonatedRecent;
    @FXML private TableView<Person> table;
    @FXML private TextField modCorreo;
    @FXML private TextField modTelefono;
    @FXML private TextField modNombre;
    @FXML private TextField modMonto;
    @FXML private Button btnMonto;
    Connection conn;
    ObservableList<Person> personList = FXCollections.observableArrayList();
    public void regresarMenu(MouseEvent event){
        try{
            Parent window3;
            window3 = (AnchorPane) FXMLLoader.load(getClass().getResource("../Menu/ViewMenui.fxml"));

            Scene newScene;
            newScene = new Scene(window3);
            newScene.setFill(Color.TRANSPARENT);
            Stage mainWindow;

            mainWindow = (Stage) ((Node)event.getSource()).getScene().getWindow();
            mainWindow.setScene(newScene);
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    public void generatePDF() throws SQLException{
        try
        {
            Document document = new Document();

            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("./AddTableExample.pdf"));
            document.open();

            PdfPTable table = new PdfPTable(6); // 3 columns.
            table.setWidthPercentage(100); //Width 100%
            table.setSpacingBefore(5f); //Space before table
            table.setSpacingAfter(5f); //Space after table

            //Set Column widths
            float[] columnWidths = {1f, 1f, 1f, 1f,1f,1f};
            table.setWidths(columnWidths);

            PdfPCell cell1 = new PdfPCell(new Paragraph("Nombres"));
            cell1.setBorderColor(BaseColor.BLUE);
            cell1.setPaddingLeft(10);
            cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell1.setVerticalAlignment(Element.ALIGN_MIDDLE);

            PdfPCell cell2 = new PdfPCell(new Paragraph("Apellido"));
            cell2.setBorderColor(BaseColor.GREEN);
            cell2.setPaddingLeft(10);
            cell2.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell2.setVerticalAlignment(Element.ALIGN_MIDDLE);

            PdfPCell cell3 = new PdfPCell(new Paragraph("Doncion acumulada"));
            cell3.setBorderColor(BaseColor.RED);
            cell3.setPaddingLeft(10);
            cell3.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell3.setVerticalAlignment(Element.ALIGN_MIDDLE);

            PdfPCell cell4 = new PdfPCell(new Paragraph("Ultima donacion"));
            cell4.setBorderColor(BaseColor.DARK_GRAY);
            cell4.setPaddingLeft(10);
            cell4.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell4.setVerticalAlignment(Element.ALIGN_MIDDLE);

            PdfPCell cell5 = new PdfPCell(new Paragraph("Correo"));
            cell5.setBorderColor(BaseColor.DARK_GRAY);
            cell5.setPaddingLeft(10);
            cell5.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell5.setVerticalAlignment(Element.ALIGN_MIDDLE);

            PdfPCell cell6 = new PdfPCell(new Paragraph("telefono"));
            cell6.setBorderColor(BaseColor.DARK_GRAY);
            cell6.setPaddingLeft(10);
            cell6.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell6.setVerticalAlignment(Element.ALIGN_MIDDLE);


            table.addCell(cell1);
            table.addCell(cell2);
            table.addCell(cell3);
            table.addCell(cell4);
            table.addCell(cell5);
            table.addCell(cell6);


            String sSQL = "Select * from donors ";
            String url = "jdbc:mysql://localhost/digitalupdate?useUnicode=true&useJDBCCompliantTimeZoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC";
            conn = DriverManager.getConnection(url,"root","12345");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sSQL);
            String[] datos= {"0","0","0","0","0","0"};
            while(rs.next()) {
                datos[0] = rs.getString("first_name");
                datos[1] = rs.getString("last_name");
                datos[2] = rs.getString("donate_recent");
                datos[3] = rs.getString("last_donated");
                datos[4] = rs.getString("email");
                datos[5] = rs.getString("phone");
                table.addCell(datos[0]);
                table.addCell(datos[1]);
                table.addCell(datos[2]);
                table.addCell(datos[3]);
                table.addCell(datos[4]);
                table.addCell(datos[5]);
            }

            document.add(table);

            document.close();
            writer.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        }catch (FileNotFoundException e){
            e.printStackTrace();
        }
    }

    @FXML
    private void initialize(){
        try{
            columnaFirstName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
            columnaLastName.setCellValueFactory(new PropertyValueFactory<>("lastName"));
            columnaEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
            columnaPhone.setCellValueFactory(new PropertyValueFactory<>("phone"));
            columnaDonatedRecent.setCellValueFactory(new PropertyValueFactory<>("recentDonated"));
            columnaLastDonated.setCellValueFactory(new PropertyValueFactory<>("lastDonated"));

            String sSQL = "Select * from donors ";
            String url = "jdbc:mysql://localhost/digitalupdate?useUnicode=true&useJDBCCompliantTimeZoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC";
            conn = DriverManager.getConnection(url,"root","12345");
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery(sSQL);
            while(rs.next()) {
                Person person;
                person = new Person(rs.getString("phone"),rs.getString("first_name"),rs.getString("last_name"),rs.getString("email"),rs.getFloat("donate_recent"),rs.getFloat("last_donated"));
                personList.add(person);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        table.setItems(personList);
        modCorreo.clear();
        modTelefono.clear();
        modNombre.clear();
        table.getSelectionModel().selectedItemProperty().addListener(new ChangeListener()
        {

            @Override
            public void changed(ObservableValue observableValue, Object oldValue, Object newValue)
            {
                if(table.getSelectionModel().getSelectedItem() != null)
                {
                    Person person = table.getSelectionModel().getSelectedItem();
                    modCorreo.setText(person.getEmail());
                    modTelefono.setText(person.getPhone());
                    modNombre.setText(person.getFirstName());
                    modMonto.setVisible(true);
                    btnMonto.setVisible(true);
                }
            }
        });
    }
    @FXML
    private void modificar(){
        try {
            table.getItems().clear();
            String query = "UPDATE donors SET email='" + modCorreo.getText() + "', phone='" + modTelefono.getText() + "' WHERE first_name='" + modNombre.getText() + "'";
            String url = "jdbc:mysql://localhost/digitalupdate?useUnicode=true&useJDBCCompliantTimeZoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC";
            conn = DriverManager.getConnection(url, "root", "12345");
            Statement st = conn.createStatement();
            st.executeUpdate(query);
            initialize();
        }catch (Exception e){
            e.printStackTrace();
        }
        table.setItems(personList);
    }

    @FXML
    private void eliminar(){
        try {
            table.getItems().clear();
            String query = "DELETE FROM donors WHERE first_name='"+modNombre.getText()+"'";
            String url = "jdbc:mysql://localhost/digitalupdate?useUnicode=true&useJDBCCompliantTimeZoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC";
            conn = DriverManager.getConnection(url, "root", "12345");
            Statement st = conn.createStatement();
            st.executeUpdate(query);
            initialize();
        }catch (Exception e){
            e.printStackTrace();
        }
        table.setItems(personList);
    }

    @FXML
    private void agregarMonto(){
        try {
            table.getItems().clear();
        String sSQL = "SELECT * FROM donors WHERE first_name='"+modNombre.getText()+"'";
        String url = "jdbc:mysql://localhost/digitalupdate?useUnicode=true&useJDBCCompliantTimeZoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC";
        conn = DriverManager.getConnection(url, "root", "12345");
        Statement st = conn.createStatement();
        ResultSet rs = st.executeQuery(sSQL);
        rs.next();
        float monto = rs.getFloat("donate_recent");
        monto += parseFloat(modMonto.getText());
        String sSQL2 = "UPDATE donors SET donate_recent="+monto+"WHERE first_name='"+modNombre.getText()+"'";
        String url2 = "jdbc:mysql://localhost/digitalupdate?useUnicode=true&useJDBCCompliantTimeZoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC";
        conn = DriverManager.getConnection(url2, "root", "12345");
        Statement st2 = conn.createStatement();
        st.executeUpdate(sSQL2);
            String sSQL3 = "UPDATE donors SET last_donated="+parseFloat(modMonto.getText())+"WHERE first_name='"+modNombre.getText()+"'";
            String url3 = "jdbc:mysql://localhost/digitalupdate?useUnicode=true&useJDBCCompliantTimeZoneShift=true&useLegacyDateTimeCode=false&serverTimezone=UTC";
            conn = DriverManager.getConnection(url3, "root", "12345");
            Statement st3 = conn.createStatement();
            st.executeUpdate(sSQL3);
            initialize();
            modNombre.clear();
            modTelefono.clear();
            modCorreo.clear();
            modMonto.clear();
    }catch (Exception e){
        e.printStackTrace();
    }}



    public static class Person{
        private final SimpleStringProperty phone;
        private final SimpleStringProperty firstName;
        private final SimpleStringProperty lastName;
        private final SimpleStringProperty email;
        private final SimpleFloatProperty recentDonated;
        private final SimpleFloatProperty lastDonated;

        private Person(String phonee,String fName, String lName, String email1,float rD,float lD) {
            this.phone=new SimpleStringProperty(phonee);
            this.firstName = new SimpleStringProperty(fName);
            this.lastName = new SimpleStringProperty(lName);
            this.email = new SimpleStringProperty(email1);
            this.recentDonated = new SimpleFloatProperty(rD);
            this.lastDonated = new SimpleFloatProperty(lD);
        }

        public String getPhone() {
            return phone.get();
        }

        public void setId(String phonee) {
            phone.set(phonee);
        }

        public String getFirstName() {
            return firstName.get();
        }
        public void setFirstName(String fName) {
            firstName.set(fName);
        }

        public String getLastName() {
            return lastName.get();
        }
        public void setLastName(String lName) {
            lastName.set(lName);
        }
        public String getEmail() {
            return email.get();
        }
        public void setEmail(String email1) {
            email.set(email1);
        }
        public float getRecentDonated() {
            return recentDonated.get();
        }
        public void setRecentDonated(float rD) {
            recentDonated.set(rD);
        }
        public float getLastDonated() {
            return lastDonated.get();
        }
        public void setLastDonated(float lD) {
            lastDonated.set(lD);
        }

    }


}
