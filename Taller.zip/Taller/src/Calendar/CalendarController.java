package Calendar;

import javafx.fxml.FXML;


import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;


import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;
import javax.mail.MessagingException;

import javax.mail.Message;



public class CalendarController {
    @FXML
    private TextField nombreEvento;
    @FXML
    private TextField lugarEvento;
    @FXML
    private TextField fechaEvento;

    private String remitente = "fabianestradavazquez.1h.11";
    private String destinatario =  "ali_lobos@hotmail.com";
    Properties props = System.getProperties();
    Session session;
    String clave="fabi191200_strada";
    MimeMessage message;
        @FXML
        public void enviar() {
            conexionGmail();
            String contentEvento = "La fundacion GreenWorld lo invita al evento " + nombreEvento.getText() + "\n" +
                    "Evento que se llevará a cabo en " + lugarEvento.getText() + "\n" +
                    "El dia " + fechaEvento.getText() + "\n" +
                    "De antemano agradecemos su presencia\n" +
                    "==================\n" +
                    "Atentamente Digital Update\n";
                try {
                    message.setFrom(new InternetAddress(remitente));
                    message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));   //Se podrían añadir varios de la misma manera
                    message.setSubject(nombreEvento.getText());
                    message.setText(contentEvento);
                    Transport transport = session.getTransport("smtp");
                    transport.connect("smtp.gmail.com", remitente, clave);
                    transport.sendMessage(message, message.getAllRecipients());
                    transport.close();
                }catch (MessagingException me){
                    me.printStackTrace();
                }

        }

    public void conexionGmail(){
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.user", remitente);
        props.put("mail.smtp.clave", "EventosGestorade123");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", "587");
        session = Session.getDefaultInstance(props);
        message = new MimeMessage(session);
    }
    public void regresarMenu(MouseEvent event){
        try{
            Parent window3;
            window3 = (AnchorPane) FXMLLoader.load(getClass().getResource("../Menu/ViewMenui.fxml"));

            Scene newScene;
            newScene = new Scene(window3);
            newScene.setFill(Color.TRANSPARENT);
            Stage mainWindow;

            mainWindow = (Stage) ((Node)event.getSource()).getScene().getWindow();
            mainWindow.setScene(newScene);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
